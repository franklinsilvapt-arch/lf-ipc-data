# lf-ipc-data

Dados anuais do IPC portugues (taxa de variacao media anual, %) para a Calculadora de Inflacao do LiteraciaFinanceira.pt.

## Estrutura

- `data/ipc-anual.json`: serie 1960-presente. E este ficheiro que a calculadora vai buscar em runtime (via raw.githubusercontent.com).
- `pipeline/update_ipc.py`: script que acrescenta o ano mais recente a serie.
- `.github/workflows/update-ipc.yml`: corre o script a 20 de janeiro de cada ano (apos o INE publicar a inflacao media anual do ano anterior) e faz commit do JSON atualizado. Pode ser corrido manualmente na tab Actions (workflow_dispatch).

## Fontes

- Serie historica 1960-1998: PORDATA (fonte INE), serie encadeada base 2025.
- 1999-presente: INE. A atualizacao anual e feita via BPstat (Banco de Portugal), serie 5721550 (IPC total, taxa de variacao media dos ultimos 12 meses); o valor de dezembro corresponde a inflacao media anual publicada pelo INE.

Os valores historicos sao finais e nunca mudam; o pipeline apenas acrescenta o ano novo.
